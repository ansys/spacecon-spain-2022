"""
.. _ref_example:

======================
A full PyMAPDL example
======================

Let's see a full PyMAPDL example!

"""

print("Under construction!")
